IcoFX Portable Launcher
=======================
Copyright (C) 2004-2009 John T. Haller
Copyright (C) 2008-2009 Vic Saville

Website: http://PortableApps.com/Development/Test

This software is OSI Certified Open Source Software.
OSI Certified is a certification mark of the Open Source Initiative.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.

ABOUT ICOFX PORTABLE
====================
The IcoFX Portable Launcher allows you to run IcoFX from a removable drive whose 
letter changes as you move it to another computer. The application can be 
entirely self-contained on the drive and then used on any Windows computer.

LICENSE
=======
This code is released under the GPL. The source is included with this package as 
IcoFXPortable.nsi.

INSTALLATION / DIRECTORY STRUCTURE
==================================
By default, the program expects the following directory structure:

-\ <--- Directory with IcoFXPortable.exe
	+\App\
		+\IcoFX\
	+\Data\
		+\settings\

It can be used in other directory configurations by including the 
IcoFXPortable.ini file in the same directory as IcoFXPortable.exe and 
configuring it as detailed in the INI file section below.

ICOFXPORTABLE.INI CONFIGURATION
===============================
The IcoFX Portable Launcher will look for an INI file called IcoFXPortable.ini 
(read the previous section for details on placement). If you are happy with the 
default options, it is not necessary, though. The INI file is formatted as 
follows:

[IcoFXPortable]
IcoFXDirectory=App\IcoFX
SettingsDirectory=Data\settings
IcoFXExecutable=IcoFX.exe
AdditionalParameters=
DisableSplashScreen=false

The IcoFXDirectory and SettingsDirectory entries should be set to the *relative* 
path to the appropriate directories from the current directory. All must be a 
subdirectory (or multiple subdirectories) of the directory containing 
IcoFXPortable.exe. The default entries for these are described in the 
installation section above.

The IcoFXExecutable entry allows you to set the IcoFX Portable Launcher to use 
an alternate EXE call to launch IcoFX. This is helpful if you are using a 
machine that is set to deny IcoFX.exe from running. You'll need to rename the 
IcoFX.exe file and then enter the name you gave it on the IcoFXExecutable= line 
of the INI.

The AdditionalParameters entry allows you to pass additional commandline 
parameter entries to IcoFX.exe. Whatever you enter here will be appended to the 
call to IcoFX.exe.

The DisableSplashScreen entry allows you to run the IcoFX Portable Launcher 
without the splash screen showing up. The default is false.